/* midiwin32.h -- system-specific definitions */

void pm_winmm_init( void );
void pm_winmm_term( void );

